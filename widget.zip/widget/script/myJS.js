


function getTitle(){
    
    
    /*
     说明
     
     js函数中回调必须这么写browser.callback('字符串')
     browser是原生里约束的名字，callback为原生里面的方法，然后使用原生传送数据，只能用于字符串传递
     
     */
    
    var callInfo = JSON.stringify({"jianshu": "http://www.jianshu.com/users/55c8fdc3c6e7/latest_articles"});
    browser.callback(callInfo);

}
